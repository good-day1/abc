package com.demo.service;

import com.demo.entity.Record;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 123
 * @since 2023-11-20
 */
public interface IRecordService extends IService<Record> {

}
