package com.demo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.demo.entity.Menu;

public interface MenuService extends IService<Menu> {
}
