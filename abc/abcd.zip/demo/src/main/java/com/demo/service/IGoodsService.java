package com.demo.service;

import com.demo.entity.Goods;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 123
 * @since 2023-11-17
 */
public interface IGoodsService extends IService<Goods> {

}
